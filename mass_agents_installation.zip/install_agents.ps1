param ($csv_path = $(throw "Path to csv file is not specified"))

$A = Import-Csv -Path $csv_path -Header 'HostIP', 'AgentURL'

$A | ForEach-Object {
    $h_name = [System.Net.Dns]::gethostentry($_.HostIP).HostName


    Invoke-Command -ComputerName $h_name -ArgumentList $_.AgentURL -ScriptBlock {
        $zip_path = 'c:\windows\temp\hwragent.zip'

        [Net.ServicePointManager]::SecurityProtocol =  [Enum]::ToObject([Net.SecurityProtocolType], 3072)
        [Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
        (New-Object Net.WebClient).DownloadFile($args[0], $zip_path)

        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zip_path, 'c:\windows\temp\hwragent')

        Start-Process msiexec.exe -Wait -ArgumentList '/I C:\windows\temp\hwragent\hwragent.msi /quiet'
    }
}
